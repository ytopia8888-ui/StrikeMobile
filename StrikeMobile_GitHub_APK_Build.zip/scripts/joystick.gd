extends Control

signal move_changed(value: Vector2)

var finger_id := -1
var center := Vector2.ZERO
var stick := Vector2.ZERO
var radius := 68.0

func _ready() -> void:
    custom_minimum_size = Vector2(170, 170)
    center = custom_minimum_size / 2.0
    queue_redraw()

func _draw() -> void:
    draw_circle(center, radius, Color(0.04, 0.06, 0.07, 0.38))
    draw_arc(center, radius, 0, TAU, 48, Color(0.85, 0.9, 0.92, 0.65), 3.0)
    draw_circle(center + stick * radius, 29.0, Color(0.8, 0.86, 0.88, 0.65))

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and finger_id == -1:
            finger_id = event.index
            _update_stick(event.position)
        elif not event.pressed and event.index == finger_id:
            finger_id = -1
            stick = Vector2.ZERO
            move_changed.emit(Vector2.ZERO)
            queue_redraw()
    elif event is InputEventScreenDrag and event.index == finger_id:
        _update_stick(event.position)

func _update_stick(pos: Vector2) -> void:
    var local := pos
    stick = (local - center) / radius
    if stick.length() > 1.0:
        stick = stick.normalized()
    move_changed.emit(Vector2(stick.x, stick.y))
    queue_redraw()
