extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
const BotScript = preload("res://scripts/bot.gd")
const HUDScript = preload("res://scripts/hud.gd")

var player
var hud
var bots: Array[Node3D] = []
var score := 0
var round_time := 120.0
var game_over := false

func _ready() -> void:
    _make_environment()
    _make_map()
    player = CharacterBody3D.new()
    player.name = "Player"
    player.set_script(PlayerScript)
    player.position = Vector3(0, 1.0, 8)
    add_child(player)
    hud = CanvasLayer.new()
    hud.name = "HUD"
    hud.set_script(HUDScript)
    add_child(hud)
    hud.setup(player, self)
    for i in range(5):
        _spawn_bot(i)

func _process(delta: float) -> void:
    if game_over:
        return
    round_time = maxf(0.0, round_time - delta)
    if is_instance_valid(hud):
        hud.update_status(player.health, score, int(round_time), bots.size())
    if round_time <= 0.0:
        game_over = true
        hud.show_message("ВРЕМЯ ВЫШЛО — нажми ПЕРЕЗАПУСК")

func _make_environment() -> void:
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.sky.sky_material = ProceduralSkyMaterial.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.58, 0.62, 0.68)
    env.ambient_light_energy = 0.7
    env_node.environment = env
    add_child(env_node)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52, -28, 0)
    sun.light_energy = 1.1
    add_child(sun)

func _mat(color: Color, roughness: float = 1.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m

func _box(parent: Node3D, pos: Vector3, size: Vector3, color: Color, name: String = "Box") -> StaticBody3D:
    var body := StaticBody3D.new()
    body.name = name
    body.position = pos
    var mesh := MeshInstance3D.new()
    var box_mesh := BoxMesh.new()
    box_mesh.size = size
    mesh.mesh = box_mesh
    mesh.material_override = _mat(color)
    body.add_child(mesh)
    var shape := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    shape.shape = box_shape
    body.add_child(shape)
    parent.add_child(body)
    return body

func _make_map() -> void:
    _box(self, Vector3(0, -0.35, 0), Vector3(34, 0.7, 34), Color(0.30, 0.32, 0.30), "Ground")
    # Outer walls
    _box(self, Vector3(0, 2, -17), Vector3(34, 4, 0.6), Color(0.48, 0.46, 0.40), "NorthWall")
    _box(self, Vector3(0, 2, 17), Vector3(34, 4, 0.6), Color(0.48, 0.46, 0.40), "SouthWall")
    _box(self, Vector3(-17, 2, 0), Vector3(0.6, 4, 34), Color(0.48, 0.46, 0.40), "WestWall")
    _box(self, Vector3(17, 2, 0), Vector3(0.6, 4, 34), Color(0.48, 0.46, 0.40), "EastWall")
    # Concrete cover, crates, and central divider
    _box(self, Vector3(-7, 0.8, -5), Vector3(3, 1.6, 2), Color(0.50, 0.43, 0.31), "CrateA")
    _box(self, Vector3(7, 0.8, -7), Vector3(2.4, 1.6, 2.4), Color(0.48, 0.39, 0.28), "CrateB")
    _box(self, Vector3(-8, 0.8, 6), Vector3(2.5, 1.6, 2.5), Color(0.48, 0.39, 0.28), "CrateC")
    _box(self, Vector3(8, 0.8, 6), Vector3(3.0, 1.6, 2.0), Color(0.48, 0.39, 0.28), "CrateD")
    _box(self, Vector3(0, 1.0, -2), Vector3(8, 2.0, 0.8), Color(0.42, 0.43, 0.41), "MiddleCover")
    _box(self, Vector3(-3.5, 0.55, 11), Vector3(2, 1.1, 2), Color(0.38, 0.40, 0.39), "ConcreteBlock")
    _box(self, Vector3(4.5, 0.55, -11), Vector3(2, 1.1, 2), Color(0.38, 0.40, 0.39), "ConcreteBlock2")
    # Painted target-like floor markers
    for x in [-12, 12]:
        var marker := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = Vector3(2.4, 0.04, 2.4)
        marker.mesh = mesh
        marker.position = Vector3(x, 0.03, 0)
        marker.material_override = _mat(Color(0.70, 0.58, 0.26))
        add_child(marker)

func _spawn_bot(index: int) -> void:
    var bot := CharacterBody3D.new()
    bot.name = "Bot_%d" % index
    bot.set_script(BotScript)
    var spawn_points = [
        Vector3(-10, 0.1, -10), Vector3(10, 0.1, -10),
        Vector3(-11, 0.1, 3), Vector3(11, 0.1, 3),
        Vector3(0, 0.1, -13)
    ]
    bot.position = spawn_points[index % spawn_points.size()]
    bot.player_ref = player
    bot.bot_died.connect(_on_bot_died)
    add_child(bot)
    bots.append(bot)

func _on_bot_died(bot: Node3D) -> void:
    score += 1
    bots.erase(bot)
    if bots.is_empty():
        game_over = true
        hud.show_message("ПОБЕДА! Все противники устранены")

func restart_game() -> void:
    get_tree().reload_current_scene()
