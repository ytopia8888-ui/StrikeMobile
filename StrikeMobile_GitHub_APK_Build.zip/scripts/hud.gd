extends CanvasLayer

var player_ref
var main_ref
var status_label: Label
var ammo_label: Label
var message_label: Label
var joystick: Control

func setup(player, main) -> void:
    player_ref = player
    main_ref = main
    player_ref.hud_ref = self
    player_ref.main_ref = main
    _build_ui()

func _build_ui() -> void:
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)

    status_label = Label.new()
    status_label.position = Vector2(22, 16)
    status_label.add_theme_font_size_override("font_size", 22)
    status_label.add_theme_color_override("font_color", Color.WHITE)
    root.add_child(status_label)

    ammo_label = Label.new()
    ammo_label.anchor_left = 1.0
    ammo_label.anchor_right = 1.0
    ammo_label.offset_left = -220
    ammo_label.offset_right = -24
    ammo_label.offset_top = 20
    ammo_label.offset_bottom = 60
    ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    ammo_label.add_theme_font_size_override("font_size", 24)
    ammo_label.add_theme_color_override("font_color", Color.WHITE)
    root.add_child(ammo_label)
    update_ammo(player_ref.ammo, player_ref.reserve_ammo)

    message_label = Label.new()
    message_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    message_label.offset_left = -330
    message_label.offset_right = 330
    message_label.offset_top = -70
    message_label.offset_bottom = -20
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 25)
    message_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
    root.add_child(message_label)

    # Movement pad
    joystick = Control.new()
    joystick.set_script(load("res://scripts/joystick.gd"))
    joystick.position = Vector2(35, -190)
    joystick.anchor_top = 1.0
    joystick.anchor_bottom = 1.0
    joystick.custom_minimum_size = Vector2(170, 170)
    root.add_child(joystick)
    joystick.move_changed.connect(_on_move_changed)

    _add_button(root, "ОГОНЬ", Vector2(-155, -165), Vector2(120, 90), "fire")
    _add_button(root, "ПРЫЖОК", Vector2(-285, -105), Vector2(100, 65), "jump")
    _add_button(root, "ПЕРЕЗАРЯДКА", Vector2(-285, -35), Vector2(135, 55), "reload")
    _add_button(root, "ПЕРЕЗАПУСК", Vector2(-170, 18), Vector2(150, 48), "restart")

func _add_button(root: Control, text_value: String, offset: Vector2, size_value: Vector2, action: String) -> void:
    var b := Button.new()
    b.text = text_value
    b.anchor_left = 1.0
    b.anchor_right = 1.0
    b.anchor_top = 1.0
    b.anchor_bottom = 1.0
    b.offset_left = offset.x
    b.offset_right = offset.x + size_value.x
    b.offset_top = offset.y
    b.offset_bottom = offset.y + size_value.y
    b.add_theme_font_size_override("font_size", 17 if action != "reload" else 13)
    b.add_theme_color_override("font_color", Color.WHITE)
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.08, 0.10, 0.12, 0.78)
    normal.border_width_left = 2
    normal.border_width_top = 2
    normal.border_width_right = 2
    normal.border_width_bottom = 2
    normal.border_color = Color(0.65, 0.72, 0.76, 0.8)
    normal.corner_radius_top_left = 12
    normal.corner_radius_top_right = 12
    normal.corner_radius_bottom_left = 12
    normal.corner_radius_bottom_right = 12
    b.add_theme_stylebox_override("normal", normal)
    root.add_child(b)
    if action == "fire":
        b.button_down.connect(func(): player_ref.fire_held = true)
        b.button_up.connect(func(): player_ref.fire_held = false)
        b.pressed.connect(func(): player_ref.wants_fire = true)
    elif action == "jump":
        b.pressed.connect(func(): player_ref.wants_jump = true)
    elif action == "reload":
        b.pressed.connect(func(): player_ref.reload_weapon())
    elif action == "restart":
        b.pressed.connect(func(): main_ref.restart_game())

func _on_move_changed(value: Vector2) -> void:
    player_ref.mobile_move = value

func update_status(health: int, score: int, time_left: int, enemy_count: int) -> void:
    if is_instance_valid(status_label):
        status_label.text = "ЗДОРОВЬЕ %d   |   УСТРАНЕНО %d   |   ПРОТИВНИКОВ %d   |   %02d:%02d" % [health, score, enemy_count, time_left / 60, time_left % 60]

func update_ammo(current: int, reserve: int) -> void:
    if is_instance_valid(ammo_label):
        ammo_label.text = "ПАТРОНЫ  %02d / %02d" % [current, reserve]

func show_message(value: String) -> void:
    message_label.text = value
