extends CharacterBody3D

const SPEED := 5.2
const JUMP_VELOCITY := 4.5
const SENSITIVITY := 0.0025
var health := 100
var ammo := 30
var reserve_ammo := 90
var gravity: float = 12.0
var camera: Camera3D
var pitch := 0.0
var shoot_cooldown := 0.0
var hud_ref
var main_ref
var mobile_move := Vector2.ZERO
var wants_jump := false
var wants_fire := false
var fire_held := false
var is_reloading := false

func _ready() -> void:
    add_to_group("player")
    var col := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.36
    capsule.height = 1.75
    col.shape = capsule
    col.position.y = 0.88
    add_child(col)
    camera = Camera3D.new()
    camera.position = Vector3(0, 1.55, 0)
    camera.current = true
    add_child(camera)
    _make_weapon_view()

func _make_weapon_view() -> void:
    var weapon := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = Vector3(0.18, 0.16, 0.62)
    weapon.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.12, 0.13, 0.14)
    weapon.material_override = mat
    weapon.position = Vector3(0.30, -0.27, -0.48)
    camera.add_child(weapon)

func _physics_process(delta: float) -> void:
    shoot_cooldown = maxf(0.0, shoot_cooldown - delta)
    if not is_on_floor():
        velocity.y -= gravity * delta
    elif wants_jump:
        velocity.y = JUMP_VELOCITY
    wants_jump = false
    var input_dir := mobile_move
    if input_dir.length() > 1.0:
        input_dir = input_dir.normalized()
    var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
    velocity.x = direction.x * SPEED
    velocity.z = direction.z * SPEED
    move_and_slide()
    if wants_fire or fire_held:
        shoot()
    wants_fire = false

func _input(event: InputEvent) -> void:
    if event is InputEventScreenDrag:
        var viewport_size = get_viewport().get_visible_rect().size
        if event.position.x < viewport_size.x * 0.68 and event.position.y < viewport_size.y * 0.82:
            rotate_y(-event.relative.x * SENSITIVITY)
            pitch = clampf(pitch - event.relative.y * SENSITIVITY, -1.35, 1.35)
            camera.rotation.x = pitch
    elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        rotate_y(-event.relative.x * SENSITIVITY)
        pitch = clampf(pitch - event.relative.y * SENSITIVITY, -1.35, 1.35)
        camera.rotation.x = pitch
    elif event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_W: mobile_move.y = -1
        if event.keycode == KEY_S: mobile_move.y = 1
        if event.keycode == KEY_A: mobile_move.x = -1
        if event.keycode == KEY_D: mobile_move.x = 1
        if event.keycode == KEY_SPACE: wants_jump = true
        if event.keycode == KEY_R: reload_weapon()
        if event.keycode == KEY_ESCAPE: Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    elif event is InputEventKey and not event.pressed:
        if event.keycode == KEY_W or event.keycode == KEY_S: mobile_move.y = 0
        if event.keycode == KEY_A or event.keycode == KEY_D: mobile_move.x = 0

func shoot() -> void:
    if shoot_cooldown > 0.0 or is_reloading:
        return
    if ammo <= 0:
        reload_weapon()
        return
    ammo -= 1
    shoot_cooldown = 0.16
    var from := camera.global_position
    var to := from + (-camera.global_transform.basis.z * 80.0)
    var query := PhysicsRayQueryParameters3D.create(from, to)
    query.exclude = [self]
    var hit = get_world_3d().direct_space_state.intersect_ray(query)
    if hit and hit.collider and hit.collider.is_in_group("bots"):
        hit.collider.take_damage(34)
    if hud_ref:
        hud_ref.update_ammo(ammo, reserve_ammo)

func reload_weapon() -> void:
    if is_reloading or ammo >= 30 or reserve_ammo <= 0:
        return
    is_reloading = true
    await get_tree().create_timer(1.2).timeout
    var need = 30 - ammo
    var amount = mini(need, reserve_ammo)
    ammo += amount
    reserve_ammo -= amount
    is_reloading = false
    if hud_ref:
        hud_ref.update_ammo(ammo, reserve_ammo)

func take_damage(amount: int) -> void:
    health = maxi(0, health - amount)
    if health <= 0 and main_ref:
        main_ref.game_over = true
        hud_ref.show_message("ТЫ ПОГИБ — нажми ПЕРЕЗАПУСК")
