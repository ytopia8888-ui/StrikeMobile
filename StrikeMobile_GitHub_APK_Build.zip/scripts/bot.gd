extends CharacterBody3D

signal bot_died(bot: Node3D)

var player_ref: Node3D
var health := 100
var attack_timer := 1.0
var wander_timer := 0.0
var wander_dir := Vector3.ZERO
var gravity := 12.0
var body_mesh: MeshInstance3D

func _ready() -> void:
    add_to_group("bots")
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.34
    capsule.height = 1.65
    shape.shape = capsule
    shape.position.y = 0.82
    add_child(shape)
    body_mesh = MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.34
    mesh.height = 1.65
    body_mesh.mesh = mesh
    body_mesh.position.y = 0.82
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.55, 0.18, 0.13)
    body_mesh.material_override = mat
    add_child(body_mesh)
    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.22
    head_mesh.height = 0.44
    head.mesh = head_mesh
    head.position.y = 1.72
    head.material_override = mat
    add_child(head)

func _physics_process(delta: float) -> void:
    if not is_instance_valid(player_ref):
        return
    if not is_on_floor():
        velocity.y -= gravity * delta
    var to_player: Vector3 = player_ref.global_position - global_position
    to_player.y = 0
    var distance := to_player.length()
    attack_timer -= delta
    if distance > 5.0:
        var dir := to_player.normalized()
        velocity.x = dir.x * 2.0
        velocity.z = dir.z * 2.0
        look_at(Vector3(player_ref.global_position.x, global_position.y, player_ref.global_position.z), Vector3.UP)
    else:
        velocity.x = move_toward(velocity.x, 0.0, 5.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 5.0 * delta)
        if attack_timer <= 0.0:
            attack_timer = randf_range(0.8, 1.5)
            if player_ref.has_method("take_damage"):
                player_ref.take_damage(randi_range(4, 9))
    move_and_slide()

func take_damage(amount: int) -> void:
    health -= amount
    if health <= 0:
        bot_died.emit(self)
        queue_free()
