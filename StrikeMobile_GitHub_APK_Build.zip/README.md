# Strike Mobile — Godot 4 prototype

A lightweight Android-friendly, first-person shooter prototype inspired by classic tactical FPS games.

## Included
- Procedurally built low-poly training map (walls, crates, cover)
- First-person camera and simple weapon model
- Five basic bots that chase and attack the player
- Health, ammo, reload, score, round timer and restart
- Touch joystick and on-screen fire/jump/reload buttons
- Keyboard/mouse support for testing on a PC
- Godot 4 / GL Compatibility renderer for older mobile GPUs

## Build on Android
1. Install **Godot 4.x** from the official Godot website or Android editor distribution.
2. Extract this ZIP.
3. Open the extracted folder as a project in Godot.
4. Press Play to test.
5. For APK export, install Android build templates and configure Android SDK/JDK in Editor Settings, then use Project > Export > Android.

This is source code, not a prebuilt APK. The project is a playable prototype, not a complete commercial game. Test on the target device and adjust the rendering settings if needed.

## Internet model assets
This starter project uses generated low-poly geometry so it runs without downloading large assets. To add downloadable models, use assets whose license permits redistribution/modification, for example:
- Kenney free game assets: https://kenney.nl/assets
- Quaternius free low-poly assets: https://quaternius.com/
Check each pack's current license and attribution requirements before including assets in a redistributed build.

## Controls
- Touch: left joystick to move; drag on the open area to look around.
- Fire: shoot toward the center of the screen.
- Jump: jump.
- Reload: refill magazine.
- Restart: restart the round.
- Desktop testing: WASD, mouse look (capture mouse by clicking game window), Space, R.

## Notes
- Bots use deliberately simple AI and do not navigate around every obstacle intelligently.
- Multiplayer, planted bomb mode, sound effects, animations, weapon selection, and imported character models are not included yet.

## Build APK automatically on GitHub
The repository includes `.github/workflows/build-android.yml` and `export_presets.cfg`.
Upload the project contents to a GitHub repository. On each push to `main`/`master`, or when manually run from the Actions tab, GitHub Actions attempts to export a debug APK. Open the completed workflow run and download the `StrikeMobile-APK` artifact. This is a debug-signed test build, not a Play Store release.
